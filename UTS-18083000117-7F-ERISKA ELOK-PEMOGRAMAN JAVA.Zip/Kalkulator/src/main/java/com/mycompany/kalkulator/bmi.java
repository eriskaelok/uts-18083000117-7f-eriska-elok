/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.kalkulator;

/**
 *
 * @author eriska elok
 */
import java.util.Scanner;
public class bmi {
    
    public static void main(String[] args){
        
        Scanner masukan = new Scanner(System.in);
        
        
        int jk;
        float berat,tinggi,bmi,meter;
        double broca;
        
        
        
        System.out.println(" PROGRAM JAVA KALKULATOR BMI (Body Mass Index)");
        System.out.println("Masukkan jenis kelamin (1.laki-laki) : (2.perempuan) : ");
        
        jk = masukan.nextInt();
        System.out.println("masukkan berat badan :");
        
        berat = masukan.nextFloat();
        System.out.println("masukkan tinggi badan :");
        
        tinggi = masukan.nextFloat();
        
        meter=tinggi/100;
        bmi=(berat/(meter*meter));
        
       
        
        System.out.println("===========================");
        System.out.println("BMI : "+bmi+" ");
        
        if(bmi <18.5){ 
            System.out.println("kurus"); 
        }
        else if (bmi <=22.9){
             System.out.println("normal");
        }
        else if (bmi <24.9){
             System.out.println("overweight");
        }
        else{
             System.out.println("obesitas");
        }
         
        switch(jk){
            case 1 : broca=((tinggi-100)-(0.10*(tinggi-100))); break;
            
            case 2 : broca=((tinggi-100)-(0.15*(tinggi-100))); break;
            
            default : broca=0;
        }
        
        
        int hasil =(int)broca;
        System.out.println("Berat badan ideal anda : "+hasil+"Kg");
        
    }
    
}
